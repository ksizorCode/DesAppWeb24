<?php
include_once '_functions.php';
$titulo='Error 404';
include '_header.php';?>
<p>Wops!, alguien ha tocado algo en alguna parte y la ha lidado</p>
<p>Posiblemente sea culpa del <del>informático</del> diseñador gráfico</p>
<p>Puedes <a href="inicio">Volver a la página de inicio</a> o ir <a href="javascript:history.back()">atras</a> para seguir navegando</a>


<?php include '_footer.php';?>