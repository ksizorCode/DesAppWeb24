
// function cambiarVista(vista) {
//     let galeria = document.querySelector('#catalogo');

//     // Eliminar todas las clases actuales de la galería
//     galeria.classList.remove('lista');
//     galeria.classList.remove('galeria');
//     galeria.classList.remove('tabla');
//     galeria.classList.remove('ficha');

//     // Agregar la clase correspondiente según la opción seleccionada
//     galeria.classList.add(vista);
//     }



// function cambiarVista(boton, vista) {
//     let galeria = document.querySelector('#catalogo');
//     let botones = document.querySelectorAll('.bntVista button');
  
//     // Eliminar la clase 'activo' de todos los botones dentro de '.bntVista'
//     botones.forEach(function(boton) {
//       boton.classList.remove('activo');
//     });
  
//     // Agregar la clase 'activo' solo al botón clicado
//     boton.classList.add('activo');
  
//     // Eliminar todas las clases actuales de la galería
//     galeria.classList.remove('galeria');
//     galeria.classList.remove('lista');
//     galeria.classList.remove('tabla');
//     galeria.classList.remove('ficha');
  
//     // Agregar la clase correspondiente según la opción seleccionada
//     galeria.classList.add(vista);

//     // lanzar función para asignar valores al slider
//     resetearSlider(vista);
//   }
  
