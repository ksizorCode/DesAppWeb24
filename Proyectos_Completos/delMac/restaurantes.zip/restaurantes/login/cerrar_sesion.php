<?php
include_once '../_functions.php';
cerrarSesion();

$titulo='La sesión se ha cerrado Correctamente';
include '../_header.php';


 include '../_footer.php';
 ?>